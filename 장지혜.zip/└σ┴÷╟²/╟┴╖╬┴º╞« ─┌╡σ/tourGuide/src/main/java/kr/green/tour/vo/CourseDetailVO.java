package kr.green.tour.vo;

import lombok.Data;

@Data
public class CourseDetailVO {
 private int course_detail_date;
 private int cd_course_id;
 private String name;
 private int course_order;
 private int cd_place_id;
}

package kr.green.tour.vo;

import lombok.Data;

@Data
public class LikesVO {
private int likes_id;
private int state;
private int likes_place_id;
private String likes_user_id;
}

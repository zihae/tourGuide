package kr.green.tour.vo;

import lombok.Data;

@Data
public class CityVO {
private int city_id;
private String city_name;

}
